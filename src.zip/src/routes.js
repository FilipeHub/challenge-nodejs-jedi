const express = require('express');

const PokemonController = require('./controllers/PokemonController');
const UserController = require('./controllers/UserController');
const SessionController = require('./controllers/SessionController');

const routes = express.Router();

routes.post('/users', UserController.store);

routes.post('/sessions', SessionController.store);

routes.post('/pokemons', PokemonController.store);

routes.get('/pokemons', PokemonController.show);

routes.get('/pokemons/:id', PokemonController.details);

routes.post('/pokemons/:id/delete', PokemonController.delete);

routes.post('/pokemons/:id/edit', PokemonController.edit);

module.exports = routes;