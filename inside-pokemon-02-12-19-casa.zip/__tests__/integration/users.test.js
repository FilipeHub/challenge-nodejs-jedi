require('dotenv').config({  
    path: process.env.NODE_ENV === "test" ? ".env.testing" : ".env"
});

const mongoose = require('mongoose');
const request = require('supertest');

const app = require('../../src/app');

const User = require("../../src/models/User");
const userInfo = {"name": "Aline3", "email": "ararara@gmail.com", "password": "123456"};

describe('Users', () => {
    beforeAll(async () => {
        mongoose.connect(process.env.DB_CONNECTION, 
            {useNewUrlParser:true,
            useCreateIndex: true,
            useUnifiedTopology: true}, (err) => {
                if (err) {
                    console.error(err);
                    process.exit(1);
                }
            });

    });
    
    it('should crate a new user', async () =>{
        
        const response = await request(app).post('/users').send(userInfo);
        console.log(response);
        console.log(response.status);
        expect(200).toBe(200);
        // await User.deleteOne({email: userInfo.email });
        // console.log(newUser);
        // expect(userInfo.email).toBe(newUser.email);
    });



    afterAll(async() => {
        mongoose.disconnect();
      });

    // afterAll(() => {
    //     await mongoose.connection.close();
    // });

});